export class Transaction {
    index: number;
    hash: string;
    notary: string;
    data: string;
    contract: string;
    recordedTime: Date;
    quantity: number;
}

export class TransactionContainer {
    states: Transaction[];
}