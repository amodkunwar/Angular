export enum Action {
    StartFlowDynamic = 'Start flow dynamic',
    NetworkMapFeed = 'Network map feed',
    Shutdown = 'Shutdown',
    Terminate = 'Terminate',
    OpenAttachment = 'Open Attachments',
    OQueryAttachments = 'OQuery Attachments'
}

export namespace ActionType {
    export const values = Object.values(Action);
}