import {BehaviorSubject} from 'rxjs';

export interface Node {
    id?: string;
    name: string;
    domain: string;
    port: number;
    jolokiaPort: number;
    username: string;
    password: string;
    heartbeat?: boolean;
    timestamp?: Date;
    lastUpdateSuccessful?: boolean;
    actionOngoing?: boolean;
    heartbeats?: BehaviorSubject<Heartbeat[]>;
    location?: Location;
}

export interface Heartbeat {
    actionTime: Date;
    success?: boolean;
    responseTime?: number;
    response?: any;
}

export interface Location {
    countryCode: string;
    city: string;
    latitude?: number;
    longitude?: number;
}
