export interface User {
    id: number;
    email: string;
    firstName: string;
    lastName: string;
    emailVerified: boolean;
    enabled: boolean;
    role: string;
    lastLogin: Date;
    nodesCount: number;
    sessionCount: number;
    actionOngoing: boolean;
}
