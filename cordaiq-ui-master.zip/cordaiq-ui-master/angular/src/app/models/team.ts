export interface Team {
    id?: string;
    name: string;
    active?: boolean;
    membersCount?: string;
    actionOngoing?: boolean;
}
