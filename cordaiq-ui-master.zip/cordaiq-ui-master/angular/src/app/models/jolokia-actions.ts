export enum JolokiaAction {
    Memory = 'Memory',
    OperatingSystem = 'Operating System',
    Runtime = 'Runtime',
    mBeanServersInfo = 'ServerHandler mBeanServersInfo()',
    Attachments = 'Corda Attachments',
    FlowsStarted = 'Corda Flows Started',
    FlowsInFlight = 'Corda Flows InFlight',
    FlowsFinished = 'Corda Flows Finished',
    CheckingPointRate = 'Corda Flows Check pointing Rate',
    CheckpointVolumeBytesPerSecondHist = 'Corda Flows CheckpointVolumeBytesPerSecondHist',
    CheckpointVolumeBytesPerSecondCurrent = 'Corda Flows CheckpointVolumeBytesPerSecondCurrent',
    PoolUsage = 'Corda HikariPool pool.Usage',
    AmqRpcServer = 'ActiveMQ RPC server',
    AmqRpcBrowse = 'ActiveMQ RPC server browse()',
    AmqRpcPause = 'ActiveMQ RPC server pause()',
    AmqRpcResume = 'ActiveMQ RPC server resume()',
    AmqRpcCount = 'ActiveMQ RPC server countMessages()',
    ApacheLog4j2 = 'Apache Log4j2'
}

export namespace JolokiaActionType {
    export const values = Object.values(JolokiaAction);
}

