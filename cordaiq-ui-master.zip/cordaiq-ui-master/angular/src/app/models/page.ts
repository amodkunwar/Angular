export interface Page<T> {
    content: T[];
    pageable: Pageable;
    totalPages: number;
    last: boolean;
    totalElements: number;
    number: number;
    size: number;
    sort: Sort;
}

export interface Pageable {
    sort: Sort;
    offset: number;
    pageNumber: number;
    pageSize: number;
    unpaged: boolean;
    paged: boolean;
}

export interface Sort {
    sorted: boolean;
    unsorted: boolean;
    empty: boolean;
}