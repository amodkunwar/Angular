import {NgModule} from '@angular/core';
import {DashboardComponent} from './dashboard.component';

@NgModule({
    imports: [],
    declarations: [DashboardComponent],
    exports: [],
    providers: []
})
export class DashboardModule {
}
