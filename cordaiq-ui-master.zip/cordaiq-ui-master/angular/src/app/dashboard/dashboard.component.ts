import {AfterViewInit, Component, NgZone, OnDestroy} from '@angular/core';

import * as am4core from '@amcharts/amcharts4/core';
import * as am4maps from '@amcharts/amcharts4/maps';
import {MapImageSeries, ZoomControl} from '@amcharts/amcharts4/maps';
import am4themes_animated from '@amcharts/amcharts4/themes/animated';
import am4geodata_worldLow from '@amcharts/amcharts4-geodata/worldLow';
import {NodeService} from "../services/node.service";
import {Subscription} from "rxjs";

@Component({
    selector: 'app-dashboard',
    templateUrl: './dashboard.component.html',
    styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent implements AfterViewInit, OnDestroy {
    private chart: am4maps.MapChart;
    private imageSeries: MapImageSeries;
    private subscription: Subscription;

    constructor(private zone: NgZone, private nodeService: NodeService) {
    }

    ngAfterViewInit(): void {
        this.zone.runOutsideAngular(() => {
            am4core.useTheme(am4themes_animated);
            // Themes end

            // Create map instance
            let chart = am4core.create("chartdiv", am4maps.MapChart);

            // Set map definition
            chart.geodata = am4geodata_worldLow;

            chart.zoomControl = new ZoomControl();

            // Set projection
            chart.projection = new am4maps.projections.Miller();

            // Create map polygon series
            let polygonSeries = chart.series.push(new am4maps.MapPolygonSeries());

            // Exclude Antartica
            polygonSeries.exclude = ["AQ"];

            // Make map load polygon (like country names) data from GeoJSON
            polygonSeries.useGeodata = true;

            // Configure series
            let polygonTemplate = polygonSeries.mapPolygons.template;
            polygonTemplate.tooltipText = "{name}";
            polygonTemplate.polygon.fillOpacity = 0.6;


            // Create hover state and set alternative fill color
            let hs = polygonTemplate.states.create("hover");
            hs.properties.fill = chart.colors.getIndex(0);

            // Add image series
            let imageSeries = chart.series.push(new am4maps.MapImageSeries());
            imageSeries.mapImages.template.propertyFields.longitude = "longitude";
            imageSeries.mapImages.template.propertyFields.latitude = "latitude";
            imageSeries.mapImages.template.tooltipText = "{title}";
            imageSeries.mapImages.template.propertyFields.url = "url";

            let circle = imageSeries.mapImages.template.createChild(am4core.Circle);
            circle.radius = 3;
            circle.propertyFields.fill = "color";

            let circle2 = imageSeries.mapImages.template.createChild(am4core.Circle);
            circle2.radius = 3;
            circle2.propertyFields.fill = "color";


            circle2.events.on("inited", function (event) {
                animateBullet(event.target);
            })


            function animateBullet(circle) {
                let animation = circle.animate([{property: "scale", from: 1, to: 5}, {
                    property: "opacity",
                    from: 1,
                    to: 0
                }], 1000, am4core.ease.circleOut);
                animation.events.on("animationended", function (event) {
                    animateBullet(event.target.object);
                })
            }

            this.imageSeries = imageSeries;
            this.chart = chart;
            this.subscribe();
        });
    }


    ngOnDestroy() {
        this.subscription.unsubscribe();
        this.zone.runOutsideAngular(() => {
            if (this.chart) {
                this.chart.dispose();
            }
        });
    }

    subscribe() {
        this.subscription = this.nodeService.nodes.subscribe(nodes => {
            let colorSet = new am4core.ColorSet();
            this.imageSeries.data = nodes
                .filter(node => node.location)//filter out nodes with no location saved
                .map(node => {
                    return {
                        title: node.name,
                        latitude: +node.location.latitude,
                        longitude: +node.location.longitude,
                        color: colorSet.next()
                    };
                });
        });
    }

}
