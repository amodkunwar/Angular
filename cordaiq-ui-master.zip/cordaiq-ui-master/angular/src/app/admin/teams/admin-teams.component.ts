import {Component, OnInit, ViewChild} from '@angular/core';
import {ColumnMode, DatatableComponent} from '@swimlane/ngx-datatable';
import {ToastrService} from 'ngx-toastr';
import {Team} from '../../models/team';
import {AdminService} from '../../services/admin.service';
import {ModalDirective} from "ngx-bootstrap/modal";
import {User} from "../../models/user";

@Component({
    selector: 'admin-teams',
    templateUrl: './admin-teams.component.html',
    styleUrls: ['./admin-teams.component.scss']
})
export class AdminTeamsComponent implements OnInit {
    @ViewChild(DatatableComponent, {static: true}) table: DatatableComponent;
    @ViewChild('teamMembersDirective', {static: true}) teamMembersDirective: ModalDirective;
    public rows: Team[];
    public basicSort: Team[];
    public columnMode = ColumnMode;
    teamMembers: User[];


    constructor(private adminService: AdminService, private toastr: ToastrService) {

    }

    ngOnInit(): void {
        this.loadUsers();
    }

    loadUsers() {
        this.adminService.findAllTeams().subscribe(page => {
            this.rows = page.content;
            this.basicSort = this.rows;
        });
    }

    public updateFilter($event: Event): void {
        const searchValue = (<HTMLInputElement>$event.target).value.toLowerCase();
        this.rows = this.basicSort.filter(item => !searchValue
            || item.name.toLowerCase().indexOf(searchValue) !== -1
        );
        // Whenever the filter changes, always go back to the first page
        this.table.offset = 0;
    }

    toggleState(team: Team) {
        team.actionOngoing = true;
        this.adminService.toggleTeamState(team).subscribe(() => {
            team.actionOngoing = false;
        }, () => {
            team.actionOngoing = false;
            this.toastr.error("Failed to toggle user status");
        });
    }

    viewMembers(team: Team) {
        team.actionOngoing = true;
        this.teamMembers = [];
        this.adminService.getTeamMembers(team).subscribe((members) => {
            this.teamMembers = members;
            this.teamMembersDirective.show();
            team.actionOngoing = false;
        }, () => {
            team.actionOngoing = false;
            this.toastr.error("Failed to force logout user");
        });
    }
}