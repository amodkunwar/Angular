import {Component, OnInit, ViewChild} from '@angular/core';
import {ColumnMode, DatatableComponent} from '@swimlane/ngx-datatable';
import {AdminService} from '../../services/admin.service';
import {User} from '../../models/user';
import {ToastrService} from "ngx-toastr";

@Component({
    selector: 'admin-users',
    templateUrl: './admin-users.component.html',
    styleUrls: ['./admin-users.component.scss']
})
export class AdminUsersComponent implements OnInit {
    @ViewChild(DatatableComponent, {static: true}) table: DatatableComponent;
    public rows: User[];
    public basicSort: User[];
    public columnMode = ColumnMode;

    constructor(private userService: AdminService, private toastr: ToastrService) {

    }

    ngOnInit(): void {
        this.loadUsers();
    }

    loadUsers() {
        this.userService.getAllUsers().subscribe(page => {
            this.rows = page.content;
            this.basicSort = this.rows;
        });
    }

    public updateFilter($event: Event): void {
        const searchValue = (<HTMLInputElement>$event.target).value.toLowerCase();
        this.rows = this.basicSort.filter(item => !searchValue
            || item.email.toLowerCase().indexOf(searchValue) !== -1
            || item.firstName && item.firstName.toLowerCase().indexOf(searchValue) !== -1
            || item.lastName && item.lastName.toLowerCase().indexOf(searchValue) !== -1
        );
        // Whenever the filter changes, always go back to the first page
        this.table.offset = 0;
    }

    toggleEnabled(user: User) {
        user.actionOngoing = true;
        this.userService.toggleEnabledUser(user).subscribe(() => {
            user.actionOngoing = false;
        }, () => {
            user.actionOngoing = false;
            this.toastr.error("Failed to toggle user status");
        });
    }

    resetPassword(user: User) {
        user.actionOngoing = true;
        this.userService.resetPassword(user).subscribe(() => {
            user.actionOngoing = false;
        }, () => {
            user.actionOngoing = false;
            this.toastr.error("Failed to reset user password");
        });
    }

    forceLogout(user: User) {
        user.actionOngoing = true;
        this.userService.forceLogout(user).subscribe(() => {
            user.actionOngoing = false;
        }, () => {
            user.actionOngoing = false;
            this.toastr.error("Failed to force logout user");
        });
    }
}