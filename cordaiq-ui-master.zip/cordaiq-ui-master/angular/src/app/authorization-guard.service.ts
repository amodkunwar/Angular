import {Injectable} from '@angular/core';
import {ActivatedRouteSnapshot, CanActivate, Router, RouterStateSnapshot} from '@angular/router';
import {AuthService} from './auth/auth.service';

@Injectable({
    providedIn: 'root'
})
export class AuthorizationGuard implements CanActivate {
    constructor(private loginServiceService: AuthService, private router: Router) {
    }

    canActivate(next: ActivatedRouteSnapshot, state: RouterStateSnapshot): boolean {
        const role = this.loginServiceService.userStatus.value.role;
        if (next.data.role) {
            if (next.data.role.indexOf(role) !== -1) {
                return true;
            } else if (this.loginServiceService.isLoggedIn()) {
                // noinspection JSIgnoredPromiseFromCall
                this.router.navigate(['/']);
            } else {
                // noinspection JSIgnoredPromiseFromCall
                this.router.navigate(['auth/login']);
            }
            return false
        } else {
            return true;
        }
    }
}
