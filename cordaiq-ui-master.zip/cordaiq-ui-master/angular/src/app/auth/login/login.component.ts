import {Component, OnInit} from '@angular/core';
import {Router} from '@angular/router';
import {HttpErrorResponse} from "@angular/common/http";
import {AuthService} from '../auth.service';

@Component({
    selector: 'app-login',
    templateUrl: './login.component.html',
    styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {
    // Sample Variables
    username;
    password;
    error;

    constructor(private loginServiceService: AuthService, private router: Router) {
    }

    ngOnInit() {
    }

    submit() {
        this.error = null;
        this.loginServiceService.doLogin(this.username, this.password).subscribe((res) => {
            // noinspection JSIgnoredPromiseFromCall
            this.router.navigate(['/dashboard']);
        }, (error: HttpErrorResponse) => {
            this.error = error.error.message;
        });
    }

}
