import {Injectable} from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {BehaviorSubject, Observable} from 'rxjs';
import {tap} from 'rxjs/operators';
import {environment} from '../../environments/environment';

@Injectable({
    providedIn: 'root'
})
export class AuthService {
    public userStatus = new BehaviorSubject<User>(AuthService.ANONYMOUS);
    private baseUrl = environment.apiUrl + '/auth';
    private static readonly ANONYMOUS = new class implements User {
        email = null;
        emailVerified = false;
        enabled = false;
        firstName = null;
        lastName = null;
        role = 'ANONYMOUS';
    };

    constructor(private httpClient: HttpClient) {
        let item = localStorage.getItem('user');
        if (item) {
            this.userStatus.next(JSON.parse(item));
        }
    }

    doLogin(email, password): Observable<User> {
        return this.httpClient.post<User>(this.baseUrl + '/login', {username: email, password})
            .pipe(
                tap((res: User) => {
                    localStorage.setItem('user', JSON.stringify(res));
                    this.userStatus.next(res);
                })
            );
    }

    isLoggedIn(): boolean {
        return this.userStatus.value?.enabled;
    }

    doRegister(form: object): Observable<any> {
        return this.httpClient.post(this.baseUrl + '/sign-up', form);
    }

    doLogout(): Observable<any> {
        return this.httpClient.post(this.baseUrl + '/logout', null)
            .pipe(
                tap((res) => {
                    this.clearAuth();
                    return res;
                })
            );
    }

    verifyEmail(token: string) {
        return this.httpClient.post(this.baseUrl + '/verify-email/' + token, null);
    }

    clearAuth() {
        localStorage.clear();
        this.userStatus.next(AuthService.ANONYMOUS);
    }
}

interface User {
    firstName: string,
    lastName: string,
    email: string,
    emailVerified: boolean,
    enabled: boolean,
    role: string,
}
