import {Component, OnInit} from '@angular/core';
import {ActivatedRoute} from '@angular/router';
import {AuthService} from '../auth.service';

@Component({
    selector: 'app-verify-email',
    templateUrl: './verify-email.component.html',
    styleUrls: ['./verify-email.component.scss']
})
export class VerifyEmailComponent implements OnInit {
    response = 'Please Wait. Verifying request...';

    constructor(private route: ActivatedRoute, private loginService: AuthService) {
    }

    ngOnInit() {
        this.route.params.subscribe(params => {
            const token = params['token'];
            this.loginService.verifyEmail(token).subscribe(() => {
                this.response = 'Your email has been verified successfully. Please login to continue.';
            }, () => {
                this.response = 'The link has been been expired or is invalid';
            });
        });
    }
}
