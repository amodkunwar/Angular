import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';

import {SharedModule} from '../@pages/components/shared.module';
import {ErrorComponent} from './error/error.component';
import {LoginComponent} from './login/login.component';
import {RegisterPageComponent} from './register/register.component';
import {VerifyEmailComponent} from './verify-email/verify-email.component';
import {RecaptchaModule} from "ng-recaptcha";

@NgModule({
    imports: [CommonModule, FormsModule, ReactiveFormsModule, SharedModule, RecaptchaModule],
    declarations: [ErrorComponent, LoginComponent, RegisterPageComponent, VerifyEmailComponent]
})
export class AuthModule {
}
