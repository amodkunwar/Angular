import {Component, OnInit} from '@angular/core';
import {Router} from '@angular/router';
import {HttpErrorResponse} from '@angular/common/http';
import {ReCaptchaV3Service} from 'ng-recaptcha';
import {AuthService} from '../auth.service';

@Component({
    selector: 'app-register-page',
    templateUrl: './register.component.html',
    styleUrls: ['./register.component.scss']
})
export class RegisterPageComponent implements OnInit {
    form = new RegisterRequest();
    error: string;

    constructor(private loginService: AuthService, private router: Router, private recaptchaV3Service: ReCaptchaV3Service) {
    }

    ngOnInit() {
    }

    doRegister() {
        this.error = null;
        this.recaptchaV3Service.execute('submit').subscribe(token => {
            this.form.captcha = token;
            this.loginService.doRegister(this.form).subscribe(() => {
                // noinspection JSIgnoredPromiseFromCall
                this.router.navigate(['auth/login']);
            }, (error: HttpErrorResponse) => {
                this.error = error.error.message || 'Could not register';
            });
        })
    }
}

class RegisterRequest {
    firstName: string;
    lastName: string;
    email: string;
    password: string;
    cPassword: string;
    inviteCode: string;
    captcha: string;

    constructor() {
    }
}
