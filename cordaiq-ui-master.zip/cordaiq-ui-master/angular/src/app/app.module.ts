import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {BrowserModule} from '@angular/platform-browser';
import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {FormsModule} from '@angular/forms';
import {HTTP_INTERCEPTORS, HttpClientModule} from '@angular/common/http';
import {RouterModule} from '@angular/router';
import {AppRoutes} from './app.routing';
import {AppComponent} from './app.component';
import {BlankComponent, BlankCorporateComponent, CorporateLayout, RootLayout} from './@pages/layouts';
import {pagesToggleService} from './@pages/services/toggler.service';
import {SidebarComponent} from './@pages/components/sidebar/sidebar.component';
import {HeaderComponent} from './@pages/components/header/header.component';
import {HorizontalMenuComponent} from './@pages/components/horizontal-menu/horizontal-menu.component';
import {SharedModule} from './@pages/components/shared.module';
import {pgCardModule} from './@pages/components/card/card.module';
import {ProgressModule} from './@pages/components/progress/progress.module';
import {NvD3Module} from 'ngx-nvd3';
import {PERFECT_SCROLLBAR_CONFIG, PerfectScrollbarConfigInterface} from 'ngx-perfect-scrollbar';
import {DashboardModule} from './dashboard/dashboard.module';

import {AuthInterceptor} from './auth-interceptor.service';
import {InitialsPipe} from './@pages/layouts/corporate/initials.pipe';
import {ToastrModule} from 'ngx-toastr';
import {BsDropdownModule} from 'ngx-bootstrap/dropdown';
import {ButtonsModule} from 'ngx-bootstrap/buttons';
import {CollapseModule} from 'ngx-bootstrap/collapse';
import {ModalModule} from 'ngx-bootstrap/modal';
import {NodesModule} from './nodes/nodes.module';
import {RECAPTCHA_V3_SITE_KEY, RecaptchaV3Module} from 'ng-recaptcha';
import {environment} from '../environments/environment';
import {TeamsModule} from './teams/teams.module';
import {AuthModule} from './auth/auth.module';
import {AdminModule} from './admin/admin.module';
import {AnalyticsModule} from './analytics/analytics.module';

const DEFAULT_PERFECT_SCROLLBAR_CONFIG: PerfectScrollbarConfigInterface = {
    suppressScrollX: true
};

@NgModule({
    declarations: [
        InitialsPipe,
        AppComponent,
        CorporateLayout,
        SidebarComponent,
        HeaderComponent,
        HorizontalMenuComponent,
        BlankComponent,
        RootLayout,
        BlankCorporateComponent,
    ],
    imports: [
        BrowserModule,
        BrowserAnimationsModule,
        CommonModule,
        FormsModule,
        HttpClientModule,
        SharedModule,
        ProgressModule,
        pgCardModule,
        RouterModule.forRoot(AppRoutes),
        BsDropdownModule.forRoot(),
        ButtonsModule.forRoot(),
        CollapseModule.forRoot(),
        ModalModule.forRoot(),
        ToastrModule.forRoot(),
        NvD3Module,
        AuthModule,
        AdminModule,
        DashboardModule,
        NodesModule,
        RecaptchaV3Module,
        TeamsModule,
        AnalyticsModule
    ],
    providers: [
        pagesToggleService,
        {
            provide: PERFECT_SCROLLBAR_CONFIG,
            useValue: DEFAULT_PERFECT_SCROLLBAR_CONFIG
        },
        {provide: HTTP_INTERCEPTORS, useClass: AuthInterceptor, multi: true},
        {provide: RECAPTCHA_V3_SITE_KEY, useValue: environment.reCaptchaSiteKey},
    ],
    bootstrap: [AppComponent]
})
export class AppModule {
}
