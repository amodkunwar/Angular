import { ViewDirective } from './view.directive';

describe('ViewDirective', () => {
  it('should create an instance', () => {
    const directive = new ViewDirective();
    expect(directive).toBeTruthy();
  });
});
