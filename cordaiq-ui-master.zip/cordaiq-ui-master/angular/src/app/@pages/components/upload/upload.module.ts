import {CommonModule} from '@angular/common';
import {NgModule} from '@angular/core';
import {FormsModule} from '@angular/forms';
import {ProgressModule} from '../progress/progress.module';
import {pgUploadBtnComponent} from './upload-btn.component';
import {pgUploadListComponent} from './upload-list.component';
import {pgUploadComponent} from './upload.component';
import {TooltipModule} from 'ngx-bootstrap/tooltip';

@NgModule({
    imports: [CommonModule, FormsModule, TooltipModule, ProgressModule],
    declarations: [pgUploadComponent, pgUploadBtnComponent, pgUploadListComponent],
    exports: [pgUploadComponent]
})
export class pgUploadModule {
}
