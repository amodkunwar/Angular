import {Component, OnInit, ViewEncapsulation} from '@angular/core';
import {pagesToggleService} from '../../services/toggler.service';
import {Router} from '@angular/router';
import {AuthService} from '../../../auth/auth.service';
import {RootLayout} from '..';

@Component({
    selector: 'corporate-layout',
    templateUrl: './corporate.component.html',
    styleUrls: ['./corporate.component.scss'],
    encapsulation: ViewEncapsulation.None
})
export class CorporateLayout extends RootLayout implements OnInit {
    menuLinks = [];
    allMenusLinks = [
        {
            label: 'Dashboard',
            routerLink: '/dashboard',
            iconType: 'pg',
            role: ['USER', 'ADMIN'],
            iconName: 'home'
        },
        {
            label: 'Nodes',
            routerLink: '/nodes',
            iconType: 'pg',
            role: ['USER', 'ADMIN'],
            iconName: 'settings_small'
        },
        {
            label: 'Analytics',
            routerLink: '/analytics',
            iconType: 'pg',
            role: ['USER', 'ADMIN'],
            iconName: 'database'
        },
        {
            label: 'Teams',
            routerLink: '/teams',
            role: ['USER', 'ADMIN'],
            iconType: 'pg',
            iconName: 'users'
        },
        {
            label: 'Admin',
            iconType: 'pg',
            iconName: 'settings',
            toggle: 'close',
            role: ['ADMIN'],
            submenu: [
                {
                    label: 'All Users',
                    routerLink: '/admin/users',
                    iconType: 'pg',
                    iconName: 'user'
                },
                {
                    label: 'All Teams',
                    routerLink: '/admin/teams',
                    iconType: 'pg',
                    iconName: 'users'
                }
            ]
        }
    ];

    user: any;

    constructor(public toggler: pagesToggleService, public router: Router, private loginService: AuthService) {
        super(toggler, router);
        this.loginService.userStatus.subscribe(user => {
            this.user = user;
        });
    }

    ngOnInit() {
        this.changeLayout('menu-pin');
        this.changeLayout('menu-behind');
        // Will sidebar close on screens below 1024
        this.autoHideMenuPin();
        this.loginService.userStatus.subscribe(user => {
            const userRole = user.role;
            this.menuLinks = this.allMenusLinks.filter(link => !link.role || link.role.indexOf(userRole) !== -1);
        });
    }

    doLogout() {
        this.loginService.doLogout().subscribe(() => {
            // noinspection JSIgnoredPromiseFromCall
            this.router.navigate(['/auth/login']);
        });
    }
}
