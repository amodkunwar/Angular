/* tslint:disable:no-any */
import {Pipe, PipeTransform} from '@angular/core';

@Pipe({name: 'initials'})
export class InitialsPipe implements PipeTransform {
    transform(name: any): any {
        if (!name) {
            return '';
        }
        return name.split(' ').map((n) => n[0]).slice(0, 2).join('');
    }
}
