import {Component, OnInit, ViewEncapsulation} from '@angular/core';

@Component({
    selector: 'layout-blank-corporate',
    templateUrl: './blank-corporate.component.html',
    styleUrls: ['./blank-corporate.component.scss'],
    encapsulation: ViewEncapsulation.None
})
export class BlankCorporateComponent implements OnInit {
    constructor() {
    }

    ngOnInit() {
    }
}
