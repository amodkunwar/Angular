export {RootLayout} from './root/root.component';
export {BlankComponent} from './blank/blank.component';
export {CorporateLayout} from './corporate/corporate.component';
export {BlankCorporateComponent} from './blank-corporate/blank-corporate.component';