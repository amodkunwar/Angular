import {Component, Input, OnInit, ViewEncapsulation} from '@angular/core';
import {Node} from "../models/node";
import {NodeService} from "../services/node.service";
import {NodeApiService} from "../services/node-api.service";
import {Transaction} from "../models/transaction";
import {ToastrService} from "ngx-toastr";

declare var pg: any;
declare let d3: any;

@Component({
    selector: 'analytics',
    templateUrl: './analytics.component.html',
    styleUrls: ['./analytics.component.scss'],
    encapsulation: ViewEncapsulation.None
})
export class AnalyticsComponent implements OnInit {
    nvd3LineData = [];
    nvd3LineOptions;
    _emphasize = false;
    _chartWrapperClass = 'col-8';
    _chartHighlightsClass = 'col-4';
    service;
    COLOR_SUCCESS = pg.getColor('success');
    COLOR_DANGER = pg.getColor('danger');
    COLOR_PRIMARY = pg.getColor('primary');
    COLOR_COMPLETE = pg.getColor('complete');
    timeout;
    public selectedNode: Node;
    nodes: Node[];
    transactions: Transaction[];

    constructor(private nodeService: NodeService, private nodeApiService: NodeApiService, private toastr: ToastrService) {
    }

    @Input()
    set Emphasize(value: boolean) {
        this._emphasize = value;
    }

    @Input()
    set ChartWrapperClass(value: string) {
        this._chartWrapperClass = value;
    }

    @Input()
    set ChartHighlightsClass(value: string) {
        this._chartHighlightsClass = value;
    }

    ngOnInit() {
        this.nodeService.nodes.subscribe(nodes => {
            return this.nodes = nodes;
        });
        // noinspection JSUnusedGlobalSymbols
        this.nvd3LineOptions = {
            chart: {
                type: 'lineChart',
                color: [this.COLOR_SUCCESS, this.COLOR_DANGER, this.COLOR_PRIMARY, this.COLOR_COMPLETE],
                x: function (transaction: Transaction) {
                    return new Date(transaction.recordedTime);
                },
                y: function (transaction: Transaction) {
                    return transaction?.quantity / 100;
                },
                // duration: 500,
                clipEdge: true,
                useInteractiveGuideline: true,
                margin: {
                    left: 30,
                    bottom: 35
                },
                showLegend: false,
                xAxis: {
                    tickFormat: (v) => d3.time.format('%H:%M:%S')(new Date(v)),
                    staggerLabels: true
                },
                yAxis: {
                    tickFormat: v => Math.round(v)
                }
            }
        };
    }

    onNodeSelection(node: Node) {
        this.selectedNode = node;
        this.nodeApiService.getTransactions(node.domain, node.port).subscribe(transactions => {
            console.log(this.transactions);
            this.transactions = transactions.states;
            this.nvd3LineData = [{key: 'Transactions', values: transactions.states}];
            window.dispatchEvent(new Event('resize'));
        }, err => {
            this.toastr.error(err.error.message, err.error.error);
        });
    }
}
