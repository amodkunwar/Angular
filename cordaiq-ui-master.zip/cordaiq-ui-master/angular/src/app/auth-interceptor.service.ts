import {Injectable} from '@angular/core';
import {
    HttpErrorResponse,
    HttpEvent,
    HttpHandler,
    HttpInterceptor,
    HttpRequest,
    HttpResponse,
} from '@angular/common/http';
import {Observable} from 'rxjs';
import {catchError, tap} from 'rxjs/operators';
import {Router} from '@angular/router';
import {ToastrService} from 'ngx-toastr';
import {AuthService} from './auth/auth.service';

@Injectable()
export class AuthInterceptor implements HttpInterceptor {

    token: any;

    constructor(private authService: AuthService, private router: Router, private toastrService: ToastrService) {
        this.authService.userStatus.subscribe(value => {
            this.token = value;
        });
    }

    // noinspection JSUnusedLocalSymbols
    onSuccess(response: HttpResponse<any>): void {
        // ignore
    }

    onError(error: HttpErrorResponse): void {
        let title, message;
        try {
            message = error.error.message;
            title = error.error.title || error.error.error;
            if (error.status === 401) {
                this.authService.clearAuth();
                // noinspection JSIgnoredPromiseFromCall
                this.router.navigate(['auth/login']);
            } else if (error.status === 403) {
                this.toastrService.error("You do not have access to the resource you are trying to access");
                // this.authService.clearAuth();
                // noinspection JSIgnoredPromiseFromCall
                // this.router.navigate(['/']);
            }
        } catch (e) {
            console.error(e);
        }
    }

    intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
        return next.handle(req).pipe(
            tap(evt => {
                if (evt instanceof HttpResponse) {
                    if (evt.body && evt.body.success) {
                        this.onSuccess(evt);
                    }
                }
            }),
            catchError((err: any) => {
                if (err instanceof HttpErrorResponse) {
                    this.onError(err);
                }
                throw err;
            }));
    }

}
