import {Injectable} from '@angular/core';
import {Observable} from 'rxjs';
import {HttpClient} from '@angular/common/http';
import {environment} from '../../environments/environment';
import {Page} from "../models/page";
import {User} from "../models/user";
import {map} from "rxjs/operators";
import {Team} from "../models/team";

@Injectable({
    providedIn: 'root'
})
export class AdminService {
    baseUrl = environment.apiUrl + '/admin';

    constructor(private httpClient: HttpClient) {
    }

    getAllUsers(): Observable<Page<User>> {
        return this.httpClient.get<Page<User>>(this.baseUrl + '/user');
    }

    toggleEnabledUser(user: User): Observable<User> {
        return this.httpClient.put(this.baseUrl + '/user/' + user.id + '/' + (!user.enabled), {})
            .pipe(map(() => {
                if (user.enabled) {
                    user.sessionCount = 0;
                }
                user.enabled = !user.enabled;
                return user;
            }));
    }

    resetPassword(user: User) {
        return this.httpClient.post(this.baseUrl + '/user/' + user.id + '/reset-password', {})
            .pipe(map(() => user));
    }

    forceLogout(user: User) {
        return this.httpClient.post(this.baseUrl + '/user/' + user.id + '/force-logout', {})
            .pipe(map(() => {
                user.sessionCount = 0;
                return user;
            }));
    }


    findAllTeams(): Observable<Page<Team>> {
        return this.httpClient.get<Page<Team>>(this.baseUrl + '/team');
    }

    getTeamMembers(team: Team): Observable<User[]> {
        return this.httpClient.get<User[]>(this.baseUrl + '/team/' + team.id + '/members');
    }

    toggleTeamState(team: Team): Observable<Team> {
        return this.httpClient.patch(this.baseUrl + '/team/' + team.id + '/' + !team.active, null)
            .pipe(
                map(() => {
                    team.active = !team.active;
                    return team;
                })
            );
    }
}
