import {Injectable} from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {environment} from '../../environments/environment';
import {JolokiaAction} from '../models/jolokia-actions';

@Injectable({
    providedIn: 'root'
})
export class JolokiaApiService {
    baseUrl = environment.apiUrl + '/../node/api/jolokia/';

    constructor(private http: HttpClient) {
    }

    public callJolokiaApi(host: string, port: number, type: JolokiaAction) {
        const request = {
            url: `http://${host}:${port}/jolokia`
        };
        let execute = false;
        switch (type) {
            case JolokiaAction.Memory:
                request['nid'] = 'java.lang:type=Memory';
                break;
            case JolokiaAction.OperatingSystem:
                request['nid'] = 'java.lang:type=OperatingSystem';
                break;
            case JolokiaAction.Runtime:
                request['nid'] = 'java.lang:type=Runtime';
                break;
            case JolokiaAction.mBeanServersInfo:
                request['nid'] = 'jolokia:type=ServerHandler';
                request['operation'] = 'mBeanServersInfo()';
                execute = true;
                break;
            case JolokiaAction.Attachments:
                request['nid'] = 'net.corda:name=Attachments';
                break;
            case JolokiaAction.FlowsStarted:
                request['nid'] = 'net.corda:type=Flows,name=Started';
                break;
            case JolokiaAction.FlowsInFlight:
                request['nid'] = 'net.corda:type=Flows,name=InFlight';
                break;
            case JolokiaAction.FlowsFinished:
                request['nid'] = 'net.corda:type=Flows,name=Finished';
                break;
            case JolokiaAction.CheckingPointRate:
                request['nid'] = 'net.corda:type=Flows,name=Checkpointing Rate';
                break;
            case JolokiaAction.CheckpointVolumeBytesPerSecondHist:
                request['nid'] = 'net.corda:type=Flows,name=CheckpointVolumeBytesPerSecondHist';
                break;
            case JolokiaAction.CheckpointVolumeBytesPerSecondCurrent:
                request['nid'] = 'net.corda:type=Flows,name=CheckpointVolumeBytesPerSecondCurrent';
                break;
            case JolokiaAction.PoolUsage:
                request['nid'] = 'net.corda:type=HikariPool-1,name=pool.Usage';
                break;
            case JolokiaAction.AmqRpcServer:
                request['nid'] = "org.apache.activemq.artemis:broker=\"RPC\",component=addresses,address=\"rpc.server\",subcomponent=queues,routing-type=\"multicast\",queue=\"rpc.server\"";
                break;
            case JolokiaAction.AmqRpcBrowse:
                request['nid'] = "org.apache.activemq.artemis:broker=\"RPC\",component=addresses,address=\"rpc.server\",subcomponent=queues,routing-type=\"multicast\",queue=\"rpc.server\"";
                request['operation'] = 'browse()';
                execute = true;
                break;
            case JolokiaAction.AmqRpcPause:
                request['nid'] = "org.apache.activemq.artemis:broker=\"RPC\",component=addresses,address=\"rpc.server\",subcomponent=queues,routing-type=\"multicast\",queue=\"rpc.server\"";
                request['operation'] = 'pause()';
                execute = true;
                break;
            case JolokiaAction.AmqRpcResume:
                request['nid'] = "org.apache.activemq.artemis:broker=\"RPC\",component=addresses,address=\"rpc.server\",subcomponent=queues,routing-type=\"multicast\",queue=\"rpc.server\"";
                request['operation'] = 'resume()';
                execute = true;
                break;
            case JolokiaAction.AmqRpcCount:
                request['nid'] = "org.apache.activemq.artemis:broker=\"RPC\",component=addresses,address=\"rpc.server\",subcomponent=queues,routing-type=\"multicast\",queue=\"rpc.server\"";
                request['operation'] = 'countMessages()';
                execute = true;
                break;
            case JolokiaAction.ApacheLog4j2:
                request['nid'] = 'org.apache.logging.log4j2:type=*';
                break;
        }
        const url = this.baseUrl + (execute ? 'execute' : 'read');
        return this.http.post(url, request);
    }
}
