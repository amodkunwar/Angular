import {Injectable} from '@angular/core';
import {BehaviorSubject, Observable, Subject} from 'rxjs';
import {HttpClient} from '@angular/common/http';
import {map} from 'rxjs/operators';
import {NodeApiService} from './node-api.service';
import {environment} from '../../environments/environment';
import {Heartbeat, Node} from '../models/node';
import {Team} from "../models/team";

@Injectable({
    providedIn: 'root'
})
export class NodeService {
    baseUrl = environment.apiUrl + '/node';
    public output = new Subject<Object>();
    public nodes: BehaviorSubject<Node[]> = new BehaviorSubject<Node[]>([]);

    constructor(private httpClient: HttpClient, private nodeApi: NodeApiService) {
        this.reloadNodes();
        this.startPollingStatus();
        setInterval(() => this.startPollingStatus(), environment.nodeHeartbeatInterval);
    }

    addNode(newNode: Node): Observable<Node> {
        return this.httpClient.post(this.baseUrl, newNode).pipe(map(obj => this.buildNode(obj)));
    }

    reloadNodes(): Observable<Node[]> {
        const observable = this.httpClient.get(this.baseUrl)
            .pipe(
                map((page: any) => page.content),
                map((contents: []) => contents.map(node => this.buildNode(node)))
            );
        observable.subscribe(nodes => this.nodes.next(nodes));
        return observable;
    }

    buildNode(obj: any): Node {
        const existingNode: Node = this.nodes.value.find(n => obj.id === n.id);
        return new class implements Node {
            id = obj.id;
            name = obj.name;
            domain = obj.domain;
            port = obj.port;
            jolokiaPort = obj.jolokiaPort;
            username = obj.username;
            password = obj.password;
            timestamp = new Date();
            actionOngoing = false;
            lastUpdateSuccessful = existingNode ? existingNode.lastUpdateSuccessful : false;
            heartbeat = obj.heartbeat;
            heartbeats = existingNode ? existingNode.heartbeats : new BehaviorSubject<Heartbeat[]>([]);
            location = obj.location;
        };
    }

    deleteNode(node: Node): Observable<Node> {
        return this.httpClient.delete(this.baseUrl + '/' + node.id)
            .pipe(
                map(() => {
                    this.nodes.next(this.nodes.value.filter(n => n !== node));
                    return node;
                })
            );
    }

    toggleHeartbeat(node: Node): Observable<Node> {
        return this.httpClient.patch(this.baseUrl + '/' + node.id + '/' + !node.heartbeat, {})
            .pipe(
                map(() => {
                    node.heartbeat = !node.heartbeat;
                    return node;
                })
            );
    }

    updateNodeLocation(nodeId, city, countryCode): Observable<any> {
        return this.httpClient.patch(this.baseUrl + '/' + nodeId + '/location', {city, countryCode});
    }

    public startPollingStatus(): void {
        if (this.nodes) {
            this.nodes.value.forEach(node => {
                if (node.heartbeat) {
                    const heartbeat: Heartbeat = {
                        actionTime: new Date(),
                    };
                    node.heartbeats.next([heartbeat, ...node.heartbeats.value]);
                    this.nodeApi.currentNodeTime(node.domain, node.port.toString())
                        .subscribe(
                            (timestamp: string) => {
                                node.timestamp = new Date(timestamp);
                                node.lastUpdateSuccessful = true;
                                heartbeat.success = true;
                                heartbeat.response = timestamp;
                                // @ts-ignore
                                heartbeat.responseTime = (new Date() - heartbeat.actionTime);
                            },
                            () => {
                                node.timestamp = new Date();
                                node.lastUpdateSuccessful = false;
                                heartbeat.success = false;
                                // @ts-ignore
                                heartbeat.responseTime = (new Date() - heartbeat.actionTime);
                            }
                        );
                }
            });
        }
    }

    getNodeTeams(node: Node): Observable<Team[]> {
        return this.httpClient.get<Team[]>(this.baseUrl + '/' + node.id + '/teams');
    }

    updateNodeTeams(node: Node, selectedTeams: Team[]) {
        return this.httpClient.put<Team[]>(this.baseUrl + '/' + node.id + '/teams', selectedTeams.map(t => t.id));
    }

    getTeamNodes(team: Team): Observable<Node[]> {
        const observable = this.httpClient.get(this.baseUrl + '/../team/' + team.id + '/nodes')
            .pipe(
                map((page: any) => page.content),
                map((contents: []) => contents.map(node => this.buildNode(node)))
            );
        observable.subscribe(nodes => this.nodes.next(nodes));
        return observable;
    }
}
