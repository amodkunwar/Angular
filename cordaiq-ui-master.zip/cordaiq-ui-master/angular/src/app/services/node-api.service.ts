import {Injectable} from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {Observable} from 'rxjs';
import {map, timeout} from 'rxjs/operators';
import {environment} from '../../environments/environment';
import {TransactionContainer} from "../models/transaction";

@Injectable({
    providedIn: 'root'
})
export class NodeApiService {
    baseUrl = environment.apiUrl + '/../node/api';

    constructor(private http: HttpClient) {
    }

    public nodeInfo(host: string, port: string): Observable<any> {
        return this.http.post(this.baseUrl + `/nodeInfo`, {host, port});
    }

    public registeredFlows(host: string, port: string): Observable<Object> {
        return this.http.post(this.baseUrl + `/registeredFlows`, {host, port});
    }

    public nodeDiagnosticInfo(host: string, port: string): Observable<Object> {
        return this.http.post(this.baseUrl + `/nodeDiagnosticInfo`, {host, port});
    }

    public currentNodeTime(host: string, port: string): Observable<Object> {
        return this.http
            .post(this.baseUrl + `/currentNodeTime`, {host, port}, {responseType: 'text'})
            .pipe(
                timeout(environment.nodeHeartbeatInterval),
            );
    }

    public networkMapFeed(host: string, port: string): Observable<Object> {
        return this.http.post(this.baseUrl + `/networkMapFeed`, {host, port});
    }

    public startFlowDynamic(host: string, port: string): Observable<Object> {
        return this.http.post(this.baseUrl + `/startFlowDynamic`, {
            host,
            port,
            amount: '100',
            currency: 'RUB',
            className: 'net.corda.finance.flows.CashIssueFlow'
        }, {responseType: 'text'});
    }

    public shutdown(host: string, port: string): Observable<Object> {
        return this.http.post(this.baseUrl + `/shutdown`, {host, port});
    }

    public terminate(host: string, port: string): Observable<Object> {
        return this.http.post(this.baseUrl + `/terminate`, {host, port, drainPendingFlows: true});
    }

    public queryAttachments(host: string, port: string): Observable<Object> {
        return this.http.post(this.baseUrl + `/queryAttachments`, {host, port});
    }

    public openAttachments(host: string, port: string, hash: string): Observable<Object> {
        return this.http.post(this.baseUrl + `/queryAttachments`, {host, port, hash});
    }

    getTransactions(host: string, port: number): Observable<TransactionContainer> {
        return this.http.post<any>(this.baseUrl + `/vaultQuery`, {
            host,
            port,
            className: 'net.corda.core.contracts.ContractState'
        }).pipe(map(data => {
            const states = [];
            for (let i = 0; i < data.states.length; i++) {
                const row = data.states[i];
                states.push({
                    index: row.ref.index,
                    hash: row.ref.hash,
                    contract: row.state.contract,
                    data: row.state.data.text,
                    notary: row.state.notary,
                    quantity: row.state.data.quantity,
                    recordedTime: data.statesMetadata[i]?.recordedTime,
                });
            }
            return {states};
        }));
    }
}
