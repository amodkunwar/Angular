import {Injectable} from '@angular/core';
import {Observable} from 'rxjs';
import {HttpClient} from '@angular/common/http';
import {map} from 'rxjs/operators';
import {environment} from '../../environments/environment';
import {Team} from '../models/team';
import {Page} from "../models/page";
import {User} from "../models/user";

@Injectable({
    providedIn: 'root'
})
export class TeamService {
    baseUrl = environment.apiUrl + '/team';

    constructor(private httpClient: HttpClient) {
    }

    addTeam(team: Team): Observable<any> {
        return this.httpClient.post(this.baseUrl, team)
    }

    addMember(teamId: number, email: string): Observable<any> {
        return this.httpClient.post(this.baseUrl + '/' + teamId + '/member', {email});
    }

    getMyTeams(): Observable<Team[]> {
        return this.httpClient.get<Team[]>(this.baseUrl + '/me');
    }

    getMembershipTeams(): Observable<Team[]> {
        return this.httpClient.get<Team[]>(this.baseUrl + '/membership');
    }

    toggleState(team: Team): Observable<Team> {
        return this.httpClient.patch(this.baseUrl + '/' + team.id + '/' + !team.active, null)
            .pipe(
                map(() => {
                    team.active = !team.active;
                    return team;
                })
            );
    }
}
