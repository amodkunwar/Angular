import {Component} from '@angular/core';
import {Node} from "../models/node";

@Component({
    selector: 'app-nodes',
    templateUrl: './nodes.component.html',
    styleUrls: ['./nodes.component.scss']
})
export class NodesComponent {
    nodeForHeartbeat: Node;
    nodeForTransaction: Node;

    showHeartbeats(node) {
        this.nodeForHeartbeat = node;
        window.dispatchEvent(new Event('resize'));
    }

    backToNodesTable() {
        this.nodeForHeartbeat = null;
        this.nodeForTransaction = null;
        window.dispatchEvent(new Event('resize'));
    }

    showTransactions(node: Node) {
        this.nodeForTransaction = node;
        window.dispatchEvent(new Event('resize'));
    }
}
