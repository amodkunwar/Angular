import {
    Component,
    Input,
    OnChanges,
    OnDestroy,
    OnInit,
    SimpleChange,
    SimpleChanges,
    ViewEncapsulation
} from '@angular/core';
import {Subscription} from 'rxjs';
import {Heartbeat, Node} from "../../models/node";

declare var pg: any;
declare let d3: any;

@Component({
    selector: 'heartbeat-graph',
    templateUrl: './heartbeat-graph.component.html',
    styleUrls: ['./heartbeat-graph.component.scss'],
    encapsulation: ViewEncapsulation.None
})
export class HeartbeatGraph implements OnInit, OnDestroy, OnChanges {
    nvd3LineData = [];
    nvd3LineOptions;
    _emphasize = false;
    _chartWrapperClass = 'col-8';
    _chartHighlightsClass = 'col-4';
    service;
    COLOR_SUCCESS = pg.getColor('success');
    COLOR_DANGER = pg.getColor('danger');
    COLOR_PRIMARY = pg.getColor('primary');
    COLOR_COMPLETE = pg.getColor('complete');
    timeout;

    @Input()
    public node: Node;
    private heartBeatSubscription: Subscription;

    constructor() {
    }

    @Input()
    set Emphasize(value: boolean) {
        this._emphasize = value;
    }

    @Input()
    set ChartWrapperClass(value: string) {
        this._chartWrapperClass = value;
    }

    @Input()
    set ChartHighlightsClass(value: string) {
        this._chartHighlightsClass = value;
    }

    ngOnChanges(changes: SimpleChanges) {
        const nodeChange: SimpleChange = changes.node;
        if (this.heartBeatSubscription) {
            this.heartBeatSubscription.unsubscribe();
        }
        if (nodeChange.currentValue) {
            this.heartBeatSubscription = nodeChange.currentValue.heartbeats.subscribe(heartbeats => {
                this.nvd3LineData = [{key: 'Heartbeats', values: heartbeats}];
                window.dispatchEvent(new Event('resize'));
            });
        }
    }

    ngOnInit() {
        // noinspection JSUnusedGlobalSymbols
        this.nvd3LineOptions = {
            chart: {
                type: 'lineChart',
                color: [this.COLOR_SUCCESS, this.COLOR_DANGER, this.COLOR_PRIMARY, this.COLOR_COMPLETE],
                x: function (heartbeat: Heartbeat) {
                    if (heartbeat) {
                        return heartbeat.actionTime;
                        // return d3.time.format('%M:%S')(heartbeat.actionTime);
                    }
                },
                y: function (heartbeat: Heartbeat) {
                    if (heartbeat) {
                        return heartbeat.responseTime;
                    }
                },
                // duration: 500,
                clipEdge: true,
                useInteractiveGuideline: true,
                margin: {
                    left: 30,
                    bottom: 35
                },
                showLegend: false,
                xAxis: {
                    tickFormat: (v) => d3.time.format('%M:%S')(new Date(v)),
                    staggerLabels: true
                },
                yAxis: {
                    tickFormat: v => Math.round(v)
                },
                forceY: [0, 1000]
            }
        };
    }

    ngOnDestroy() {
    }
}
