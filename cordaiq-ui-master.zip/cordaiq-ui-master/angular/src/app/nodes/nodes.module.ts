// Angular Dependencies
import {NgModule} from '@angular/core';

import {SWIPER_CONFIG, SwiperConfigInterface} from 'ngx-swiper-wrapper';
// Widgets
import {HeartbeatGraph} from './heartbeat-graph/heartbeat-graph.component';
import {NodesTableComponent} from './nodes-table/nodes-table.component';
import {ModalModule} from 'ngx-bootstrap/modal';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import {NgxDatatableModule} from '@swimlane/ngx-datatable';
import {CommonModule} from '@angular/common';
import {pgSelectModule} from '../@pages/components/select/select.module';
import {NvD3Module} from 'ngx-nvd3';
import {pgCardModule} from '../@pages/components/card/card.module';
import {NodesComponent} from './nodes.component';
import {TransactionsTableComponent} from './transactions-table/transactions-table.component';
import {NodesOutputComponent} from './nodes-output/nodes-output.component';
import {NgxJsonViewerModule} from 'ngx-json-viewer';

const components = [
    NodesComponent,
    HeartbeatGraph,
    NodesTableComponent,
    NodesOutputComponent,
    TransactionsTableComponent
];

const DEFAULT_SWIPER_CONFIG: SwiperConfigInterface = {
    direction: 'horizontal',
    slidesPerView: 'auto'
};

@NgModule({
    imports: [
        CommonModule,
        ModalModule,
        ReactiveFormsModule,
        NgxDatatableModule,
        pgSelectModule,
        FormsModule,
        NvD3Module,
        pgCardModule,
        NgxJsonViewerModule
    ],
    declarations: components,
    exports: components,
    providers: [
        {
            provide: SWIPER_CONFIG,
            useValue: DEFAULT_SWIPER_CONFIG
        }
    ]
})
export class NodesModule {
}
