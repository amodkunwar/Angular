import {Component, OnInit} from '@angular/core';
import {NodeService} from "../../services/node.service";

@Component({
    selector: 'nodes-output',
    templateUrl: './nodes-output.component.html',
    styleUrls: ['./nodes-output.component.scss']
})
export class NodesOutputComponent implements OnInit {

    data;

    constructor(private tableNodesWidgetService: NodeService) {
    }

    ngOnInit(): void {
        this.tableNodesWidgetService.output.subscribe((data) => {
            if (Array.isArray(data) || typeof data === 'string') {
                this.data = {data};
            } else {
                this.data = data;
            }
        });
    }
}
