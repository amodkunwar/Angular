import {Component, Input, OnChanges, SimpleChange, SimpleChanges, ViewChild} from '@angular/core';
import {ColumnMode, DatatableComponent} from '@swimlane/ngx-datatable';
import {Node} from "../../models/node";
import {NodeApiService} from "../../services/node-api.service";
import {Transaction} from "../../models/transaction";
import {ToastrService} from "ngx-toastr";

@Component({
    selector: 'transactions-table',
    templateUrl: './transactions-table.component.html',
    styleUrls: ['./transactions-table.component.scss']
})
export class TransactionsTableComponent implements OnChanges {

    @ViewChild(DatatableComponent, {static: true}) table: DatatableComponent;
    public rows: Transaction[];
    public originalData: Transaction[] = [];
    public columnMode = ColumnMode;
    @Input()
    public node: Node;
    cashOnly: boolean = false;
    private readonly SHOW_TOAST_ERR = err => {
        this.toastr.error(err.error.message, err.error.error);
    }

    constructor(private nodeApiService: NodeApiService, private toastr: ToastrService) {
    }

    ngOnChanges(changes: SimpleChanges) {
        const nodeChange: SimpleChange = changes.node;
        if (nodeChange.currentValue) {
            this.refresh();
        }
    }

    searchRows($event: Event): void {
        const searchValue = (<HTMLInputElement>$event.target).value.toLowerCase();
        this.updateFilter(searchValue);
    }

    updateFilter(searchValue?: string) {
        this.rows = this.originalData
            .filter(item => !this.cashOnly || (item.contract && item.contract === 'net.corda.finance.contracts.asset.Cash'))
            .filter(item => searchValue === null || searchValue === undefined
                || (item.hash && item.hash.toLowerCase().indexOf(searchValue) !== -1)
                || (item.contract && item.contract.toLowerCase().indexOf(searchValue) !== -1)
                || (item.data && item.data.toLowerCase().indexOf(searchValue) !== -1)
                || (item.notary && item.notary.toLowerCase().indexOf(searchValue) !== -1)
            );
        // Whenever the filter changes, always go back to the first page
        this.table.offset = 0;
    }

    refresh() {
        this.nodeApiService.getTransactions(this.node.domain, this.node.port)
            .subscribe(data => {
                this.originalData = data.states;
                this.rows = data.states;
            }, this.SHOW_TOAST_ERR);
    }

    toggleCashOnly() {
        this.cashOnly = !this.cashOnly;
        this.updateFilter();
    }
}
