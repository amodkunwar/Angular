import {Component, EventEmitter, OnInit, Output, ViewChild} from '@angular/core';
import {ColumnMode, DatatableComponent} from '@swimlane/ngx-datatable';
import {ModalDirective} from 'ngx-bootstrap/modal';
import {AbstractControl, FormControl, FormGroup, Validators} from '@angular/forms';
import {ToastrService} from 'ngx-toastr';
import {Node} from '../../models/node';
import {NodeService} from '../../services/node.service';
import {NodeApiService} from '../../services/node-api.service';
import {Action, ActionType} from '../../models/action';
import {JolokiaActionType} from '../../models/jolokia-actions';
import {JolokiaApiService} from '../../services/jolokia-api.service';
import {Team} from '../../models/team';
import {TeamService} from '../../services/team.service';

@Component({
    selector: 'admin-users',
    templateUrl: './nodes-table.component.html',
    styleUrls: ['./nodes-table.component.scss']
})
export class NodesTableComponent implements OnInit {
    private readonly NO_OP = () => {
    };
    private readonly SHOW_TOAST_ERR = err => {
        this.toastr.error(err.error.message, err.error.error);
    }

    @ViewChild(DatatableComponent, {static: true}) table: DatatableComponent;
    @ViewChild('addNodeDirective', {static: true}) addNodeDirective: ModalDirective;
    @ViewChild('updateTeamsDirective', {static: true}) updateTeamsDirective: ModalDirective;
    actions = ActionType.values;
    jolokiaActions = JolokiaActionType.values;
    rows: Node[];
    teams: Team[];
    selectedTeams: Team[];
    public basicSort: Node[] = [];
    public columnMode = ColumnMode;
    public rowAdding = false;
    private ipAddressRegex = '((?!0)(?!.*\\.$)((1?\\d?\\d|25[0-5]|2[0-4]\\d)(\\.|$)){4})';
    private hostnameRegex = '((([a-zA-Z]|[a-zA-Z][a-zA-Z0-9\\-]*[a-zA-Z0-9])\\.)*([A-Za-z]|[A-Za-z][A-Za-z0-9\\-]*[A-Za-z0-9]))';
    public formGroup = new FormGroup({
        name: new FormControl(null, {
            validators: [Validators.required]
        }),
        domain: new FormControl(null, {
            validators: [
                Validators.required,
                Validators.pattern('^' + this.ipAddressRegex + '|' + this.hostnameRegex + '$')]
        }),
        port: new FormControl(null, {
            validators: [Validators.min(0), Validators.required]
        }),
        jolokiaPort: new FormControl(null, {
            validators: [Validators.min(0), Validators.required]
        }),
        username: new FormControl('user1', {
            validators: [Validators.required]
        }),
        password: new FormControl('test', {
            validators: [Validators.required]
        })
    });
    @Output()
    private nodeSelectedForHeartbeat = new EventEmitter<Node>();

    @Output()
    private nodeSelectedForTransactions = new EventEmitter<Node>();
    private selectedNode: Node;
    membershipTeams: Team[];
    constructor(private nodeService: NodeService,
                private nodeApiService: NodeApiService,
                private toastr: ToastrService,
                private teamsService: TeamService,
                private jolokiaApiService: JolokiaApiService) {
    }

    ngOnInit(): void {
        this.nodeService.nodes.subscribe((nodes: Node[]) => {
            this.rows = nodes;
            this.basicSort = nodes;
        });
        this.teamsService.getMembershipTeams().subscribe(teams => {
            this.membershipTeams = teams;
        })
    }

    public getFormControl(name: string): AbstractControl {
        return this.formGroup.controls[name];
    }

    public onMoreActions($event: any, element: Node) {
        switch ($event) {
            case Action.StartFlowDynamic:
                return this.startFlowDynamic(element);
            case Action.NetworkMapFeed:
                return this.getNetworkMapFeed(element);
            case Action.Shutdown:
                return this.shutdown(element);
            case Action.Terminate:
                return this.terminate(element);
            case Action.OpenAttachment:
                return this.openAttachments(element);
            case Action.OQueryAttachments:
                return this.queryAttachments(element);
        }
    }

    public onJolokiaActions($event: any, element: Node) {
        this.jolokiaApiService.callJolokiaApi(element.domain, element.jolokiaPort, $event)
            .subscribe(this.appendOutput, this.SHOW_TOAST_ERR);
    }

    public updateFilter($event: Event): void {
        const searchValue = (<HTMLInputElement>$event.target).value.toLowerCase();
        this.rows = this.basicSort.filter(item => item.name.toLowerCase().indexOf(searchValue) !== -1 || !searchValue);
        // Whenever the filter changes, always go back to the first page
        this.table.offset = 0;
    }

    public showModal(): void {
        this.addNodeDirective.show();
    }

    public addNode(): void {
        const formGroupValue = this.formGroup.value;
        const newNode: Node = {
            name: formGroupValue.name,
            domain: formGroupValue.domain,
            port: formGroupValue.port,
            jolokiaPort: formGroupValue.jolokiaPort,
            username: formGroupValue.username,
            password: formGroupValue.password,
        };
        this.rowAdding = true;
        this.nodeService.addNode(newNode).subscribe(node => {
            this.toastr.success('Node added successfully');
            this.updateNodeInfo(node);
            this.rowAdding = false;
            this.addNodeDirective.hide();
        }, () => {
            this.rowAdding = false;
        });
    }

    public getNodeInfo(node: Node): void {
        this.nodeApiService.nodeInfo(node.domain, node.port.toString())
            .subscribe((nodeInfo) => {
                this.appendOutput(nodeInfo);
                this.updateNodeLocation(nodeInfo, node);
            }, this.SHOW_TOAST_ERR);
    }

    public updateNodeInfo(node: Node): void {
        this.nodeApiService.nodeInfo(node.domain, node.port.toString())
            .subscribe(nodeInfo => this.updateNodeLocation(nodeInfo, node), () => {
                this.nodeService.reloadNodes().subscribe(this.NO_OP);
            });
    }

    private updateNodeLocation(nodeInfo, node: Node) {
        const infoMap = {};
        nodeInfo.issuerDomainNames[0].split(',')
            .map(segment => segment.split('='))
            .forEach(segment => infoMap[segment[0].trim()] = segment[1].trim());
        const city = infoMap['L'];
        const countryCode = infoMap['C'];
        this.nodeService.updateNodeLocation(node.id, city, countryCode)
            .subscribe(this.NO_OP, this.SHOW_TOAST_ERR, () => this.nodeService.reloadNodes().subscribe(this.NO_OP));
    }

    public getRegisteredFlows(element: Node): void {
        this.nodeApiService.registeredFlows(element.domain, element.port.toString())
            .subscribe(this.appendOutput, this.SHOW_TOAST_ERR);
    }

    public getNodeDiagnosticInfo(element: Node): void {
        this.nodeApiService.nodeDiagnosticInfo(element.domain, element.port.toString())
            .subscribe(this.appendOutput, this.SHOW_TOAST_ERR);
    }

    public getNetworkMapFeed(element: Node): void {
        this.nodeApiService.networkMapFeed(element.domain, element.port.toString())
            .subscribe(this.appendOutput, this.SHOW_TOAST_ERR);
    }

    public startFlowDynamic(element: Node): void {
        this.nodeApiService.startFlowDynamic(element.domain, element.port.toString())
            .subscribe(this.appendOutput, this.SHOW_TOAST_ERR);
    }

    public shutdown(element: Node): void {
        this.nodeApiService.shutdown(element.domain, element.port.toString())
            .subscribe(this.appendOutput, this.SHOW_TOAST_ERR);
    }

    public terminate(element: Node) {
        this.nodeApiService.terminate(element.domain, element.port.toString())
            .subscribe(this.appendOutput, this.SHOW_TOAST_ERR);
    }

    public queryAttachments(element: Node): void {
        this.nodeApiService.queryAttachments(element.domain, element.port.toString())
            .subscribe(this.appendOutput, this.SHOW_TOAST_ERR);
    }

    public openAttachments(element: Node): void {
        const hash = '"260A94FEABB80596A2A1D71B657AFA6309917B671C8F43DA2A4CCE0CD3016C8D"';
        this.nodeApiService.openAttachments(element.domain, element.port.toString(), hash)
            .subscribe(this.appendOutput, this.SHOW_TOAST_ERR);
    }

    deleteNode(row: Node) {
        row.actionOngoing = true;
        this.nodeService.deleteNode(row).subscribe(() => {
            row.actionOngoing = false;
            this.toastr.success('Node deleted successfully');
        }, (err) => {
            row.actionOngoing = false;
            this.SHOW_TOAST_ERR(err);
        });
    }

    toggleHeartbeat(row: Node) {
        row.actionOngoing = true;
        this.nodeService.toggleHeartbeat(row).subscribe(() => {
            row.actionOngoing = false;
        }, (err) => {
            row.actionOngoing = false;
            this.SHOW_TOAST_ERR(err);
        });
    }

    showNodeHeartbeats(row: Node) {
        this.nodeSelectedForHeartbeat.emit(row);
    }

    showNodeTransactions(row: Node) {
        this.nodeSelectedForTransactions.emit(row);
    }

    appendOutput = (data: Object)=> {
        this.nodeService.output.next(data);
    }

    showUpdateTeams(row: Node) {
        this.selectedNode = row;
        this.selectedTeams = [];
        this.teamsService.getMyTeams().subscribe(teams => {
            this.teams = teams;
            this.nodeService.getNodeTeams(row).subscribe(nodeTeams => {
                const teamIds = nodeTeams.map(t => t.id);
                this.selectedTeams = this.teams.filter(t => teamIds.indexOf(t.id) !== -1);
                this.updateTeamsDirective.show();
            });
        });
    }

    updateTeams() {
        this.nodeService.updateNodeTeams(this.selectedNode, this.selectedTeams).subscribe(() => {
            this.toastr.success("Node Teams Updated Successfully");
            this.updateTeamsDirective.hide();
        }, this.SHOW_TOAST_ERR);
    }

    onTeamSelection(team: Team) {
        this.nodeService.getTeamNodes(team).subscribe(() => {
        }, this.SHOW_TOAST_ERR);
    }
}
