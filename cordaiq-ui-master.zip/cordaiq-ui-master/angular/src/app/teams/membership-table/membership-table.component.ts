import {Component, Input, OnInit, ViewChild} from '@angular/core';
import {ColumnMode, DatatableComponent} from '@swimlane/ngx-datatable';
import {TeamService} from '../../services/team.service';
import {Team} from '../../models/team';
import {Subject} from 'rxjs';

@Component({
    selector: 'admin-users',
    templateUrl: './membership-table.component.html',
    styleUrls: ['./membership-table.component.scss']
})
export class MembershipTableComponent implements OnInit {
    @ViewChild(DatatableComponent, {static: true}) table: DatatableComponent;
    public rows: Team[];
    public basicSort: Team[] = [];
    public columnMode = ColumnMode;
    @Input()
    public teamChanged: Subject<any>;

    constructor(private teamService: TeamService) {

    }

    ngOnInit(): void {
        this.loadTeams();
        this.teamChanged.subscribe(() => {
            this.loadTeams();
        })
    }

    loadTeams() {
        this.teamService.getMembershipTeams().subscribe((teams: Team[]) => {
            this.rows = teams;
            this.basicSort = teams;
        });
    }

    public updateFilter($event: Event): void {
        const searchValue = (<HTMLInputElement>$event.target).value.toLowerCase();
        this.rows = this.basicSort.filter(item => item.name.toLowerCase().indexOf(searchValue) !== -1 || !searchValue);
        // Whenever the filter changes, always go back to the first page
        this.table.offset = 0;
    }

}