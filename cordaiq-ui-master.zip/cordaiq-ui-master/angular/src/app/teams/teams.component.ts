import {Component} from '@angular/core';
import {Subject} from 'rxjs';

@Component({
    selector: 'admin',
    templateUrl: './teams.component.html',
    styleUrls: ['./teams.component.scss']
})
export class TeamsComponent {
    teamChanged = new Subject();

    onTeamsUpdate() {
        this.teamChanged.next();
    }
}
