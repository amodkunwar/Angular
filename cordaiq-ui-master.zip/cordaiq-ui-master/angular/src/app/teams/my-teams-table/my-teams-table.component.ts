import {Component, OnInit, Output, ViewChild, EventEmitter} from '@angular/core';
import {ColumnMode, DatatableComponent} from '@swimlane/ngx-datatable';
import {ModalDirective} from 'ngx-bootstrap/modal';
import {AbstractControl, FormControl, FormGroup, Validators} from '@angular/forms';
import {ToastrService} from 'ngx-toastr';
import {TeamService} from '../../services/team.service';
import {Team} from '../../models/team';

@Component({
    selector: 'my-teams-table',
    templateUrl: './my-teams-table.component.html',
    styleUrls: ['./my-teams-table.component.scss']
})
export class MyTeamsTableComponent implements OnInit {
    @ViewChild(DatatableComponent, {static: true}) table: DatatableComponent;
    @ViewChild('addTeamDirective', {static: true}) addTeamDirective: ModalDirective;
    @ViewChild('addMemberDirective', {static: true}) addMemberDirective: ModalDirective;
    public rows: Team[];
    public basicSort: Team[] = [];
    public columnMode = ColumnMode;
    public rowAdding = false;
    public newTeamForm = new FormGroup({
        name: new FormControl(null, {
            validators: [Validators.required]
        })
    });
    public newMemberForm = new FormGroup({
        email: new FormControl(null, {
            validators: [Validators.required, Validators.email]
        }),
        teamId: new FormControl(null, {
            validators: [Validators.required]
        })
    });
    @Output()
    teamsUpdate = new EventEmitter<any>();

    constructor(private teamService: TeamService, private toastr: ToastrService) {

    }

    ngOnInit(): void {
        this.loadTeams();
    }

    loadTeams() {
        this.teamService.getMyTeams().subscribe((teams: Team[]) => {
            this.rows = teams;
            this.basicSort = teams;
        });
    }

    public getTeamFormControl(name: string): AbstractControl {
        return this.newTeamForm.controls[name];
    }

    public getMemberFormControl(name: string): AbstractControl {
        return this.newMemberForm.controls[name];
    }


    public updateFilter($event: Event): void {
        const searchValue = (<HTMLInputElement>$event.target).value.toLowerCase();
        this.rows = this.basicSort.filter(item => item.name.toLowerCase().indexOf(searchValue) !== -1 || !searchValue);
        // Whenever the filter changes, always go back to the first page
        this.table.offset = 0;
    }

    public showAddTeam(): void {
        this.addTeamDirective.show();
    }

    public showAddMember(team: Team): void {
        console.log(this.newMemberForm);
        this.newMemberForm.setValue({
            teamId: team.id,
            email: ''
        })
        this.addMemberDirective.show();
    }

    public addTeam(): void {
        const formGroupValue = this.newTeamForm.value;
        const newTeam: Team = {
            name: formGroupValue.name,
        };
        this.rowAdding = true;
        this.teamService.addTeam(newTeam).subscribe(() => {
            this.toastr.success('Team added successfully');
            this.loadTeams();
            this.rowAdding = false;
            this.addTeamDirective.hide();
            this.newTeamForm.reset();
            this.teamsUpdate.emit();
        }, () => {
            this.rowAdding = false;
        });
    }

    public addMember(): void {
        const formGroupValue = this.newMemberForm.value;
        this.rowAdding = true;
        this.teamService.addMember(formGroupValue.teamId, formGroupValue.email).subscribe(() => {
            this.toastr.success('Member added successfully');
            this.loadTeams();
            this.rowAdding = false;
            this.addMemberDirective.hide();
            this.newMemberForm.reset();
            this.teamsUpdate.emit();
        }, () => {
            this.rowAdding = false;
        });
    }

    toggleState(row: Team): void {
        row.actionOngoing = true;
        this.teamService.toggleState(row).subscribe(() => {
            row.actionOngoing = false;
            this.teamsUpdate.emit();
        });
    }

}