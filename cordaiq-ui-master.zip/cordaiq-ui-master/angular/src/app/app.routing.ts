import {Routes} from '@angular/router';
// Layouts
import {BlankCorporateComponent, CorporateLayout} from './@pages/layouts';
// Sample Pages
import {DashboardComponent} from './dashboard/dashboard.component';
import {NodesComponent} from './nodes/nodes.component';
import {AuthorizationGuard} from './authorization-guard.service';
import {TeamsComponent} from './teams/teams.component';
import {LoginComponent} from './auth/login/login.component';
import {RegisterPageComponent} from './auth/register/register.component';
import {VerifyEmailComponent} from './auth/verify-email/verify-email.component';
import {ErrorComponent} from './auth/error/error.component';
import {AdminUsersComponent} from './admin/users/admin-users.component';
import {AdminTeamsComponent} from './admin/teams/admin-teams.component';
import {AnalyticsComponent} from './analytics/analytics.component';

export const AppRoutes: Routes = [
    {
        path: '',
        component: CorporateLayout,
        data: {role: ['USER', 'ADMIN']},
        canActivate: [AuthorizationGuard],
        children: [
            {
                path: 'dashboard',
                component: DashboardComponent
            },
            {
                path: 'nodes',
                component: NodesComponent
            },
            {
                path: 'teams',
                component: TeamsComponent
            },
            {
                path: 'analytics',
                component: AnalyticsComponent
            },
            {path: '', redirectTo: 'dashboard', pathMatch: 'full'},
        ]
    },
    {
        path: 'auth',
        component: BlankCorporateComponent,
        data: {role: ['ANONYMOUS']},
        canActivate: [AuthorizationGuard],
        children: [
            {
                path: 'login',
                component: LoginComponent,
            },
            {
                path: 'register',
                component: RegisterPageComponent,
            },
            {
                path: 'verify-email/:token',
                component: VerifyEmailComponent,
            },
            {
                path: '',
                pathMatch: 'full',
                redirectTo: '/login'
            },
        ],
    },
    {
        path: 'admin',
        component: CorporateLayout,
        data: {role: ['ADMIN']},
        canActivate: [AuthorizationGuard],
        children: [
            {
                path: 'users',
                component: AdminUsersComponent,
            },
            {
                path: 'teams',
                component: AdminTeamsComponent,
            }
        ]
    },
    {
        path: 'error', component: BlankCorporateComponent,
        children: [{
            path: ':status',
            component: ErrorComponent
        }]
    },
    {path: '**', redirectTo: 'error/404'},
];
