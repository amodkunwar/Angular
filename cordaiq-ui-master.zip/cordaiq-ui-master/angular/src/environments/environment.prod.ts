export const environment = {
    production: true,
    apiUrl: 'api',
    nodeHeartbeatInterval: 10000,// 5secs
    reCaptchaSiteKey: '6LdK_rUZAAAAAK5ntJ1JbTzQd9af6ZrOQg6jgSco',
};
